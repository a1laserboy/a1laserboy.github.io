Wood Grain from https://publicdomainvectors.org/en/free-clipart/Wood-grain/43630.html
